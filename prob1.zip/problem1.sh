pip install -r requirements.txt
g++ prob1.cpp -o prob1.out && ./prob1.out > prob1out.txt
python prob1.py
